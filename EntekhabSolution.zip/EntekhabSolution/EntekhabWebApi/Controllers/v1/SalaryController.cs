﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Data.Repositories;
using EntekhabWebApi.Models;
using Entities.Salary;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OvertimeMethods;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using WebFramework.Api;

namespace EntekhabWebApi.Controllers.v1
{
    [ApiVersion("1")]
    public class SalaryController : BaseController
    {
        private readonly IRepository<Salary> _repository;
        private readonly IMapper _mapper;

        public SalaryController(IRepository<Salary> repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<ActionResult<List<SalarySelectDto>>> Get(CancellationToken cancellationToken)
        {
            var list = await _repository.TableNoTracking.ProjectTo<SalarySelectDto>(_mapper.ConfigurationProvider)
                .ToListAsync(cancellationToken);

            return Ok(list);
        }

        [HttpGet("{id:int}")]
        public async Task<ApiResult<SalarySelectDto>> Get(int id, CancellationToken cancellationToken)
        {
            var dto = await _repository.TableNoTracking.ProjectTo<SalarySelectDto>(_mapper.ConfigurationProvider)
                .SingleOrDefaultAsync(p => p.Id == id, cancellationToken);

            if (dto == null)
                return NotFound();

            return dto;
        }

        [HttpPost]
        public async Task<ApiResult<SalarySelectDto>> Create(SalaryDto dto, CancellationToken cancellationToken)
        {
            var model = dto.ToEntity(_mapper);
            OvetimePolicies overtimeMethods = new OvetimePolicies();
            var OverTimeCalculator = 0;
            switch (model.OverTimeCalculator)
            {
                case "CalcurlatorA":
                    model.SalaryPaid = overtimeMethods.CalcurlatorA(model.BasicSalary, model.Allowance, model.Transportation);
                    break;

                case "CalcurlatorB":
                    OverTimeCalculator = overtimeMethods.CalcurlatorB(model.BasicSalary, model.Allowance, model.Transportation);
                    break;

                case "CalcurlatorC":
                    OverTimeCalculator = overtimeMethods.CalcurlatorC(model.BasicSalary, model.Allowance, model.Transportation);
                    break;

                default:
                    throw new InvalidOperationException("OverTimeCalculator isInvalid.");
            }


            await _repository.AddAsync(model, cancellationToken);

            var resultDto = await _repository.TableNoTracking.ProjectTo<SalarySelectDto>(_mapper.ConfigurationProvider)
                .SingleOrDefaultAsync(p => p.Id == model.Id, cancellationToken);

            return resultDto;
        }

        [HttpPut]
        public async Task<ApiResult<SalaryDto>> Update(int id, SalaryDto dto, CancellationToken cancellationToken)
        {
            var model = await _repository.GetByIdAsync(cancellationToken, id);

            model = dto.ToEntity(_mapper, model);

            await _repository.UpdateAsync(model, cancellationToken);

            var resultDto = await _repository.TableNoTracking.ProjectTo<SalaryDto>(_mapper.ConfigurationProvider)
                .SingleOrDefaultAsync(p => p.Id == model.Id, cancellationToken);

            return resultDto;
        }

        [HttpDelete("{id:int}")]
        public async Task<ApiResult> Delete(int id, CancellationToken cancellationToken)
        {
            var model = await _repository.GetByIdAsync(cancellationToken, id);
            await _repository.DeleteAsync(model, cancellationToken);

            return Ok();
        }
  }
}
