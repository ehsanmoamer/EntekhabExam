﻿using Entities.Salary;
using WebFramework.Api;

namespace EntekhabWebApi.Models
{
    public class SalaryDto : BaseDto<SalaryDto, Salary>
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        // حقوق پایه
        public int BasicSalary { get; set; }
        // فوق العاده حق جذب
        public int Allowance { get; set; }
        // حق ایاب و ذهاب
        public int Transportation { get; set; }
        // تاریخ حقوق پرداختی
        public string Date { get; set; }
        // نام متد محاسبه حقوق
        public string OverTimeCalculator { get; set; }
    }

    public class SalarySelectDto : BaseDto<SalarySelectDto, Salary>
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        // حقوق پایه
        public int BasicSalary { get; set; }
        // فوق العاده حق جذب
        public int Allowance { get; set; }
        // حق ایاب و ذهاب
        public int Transportation { get; set; }
        // تاریخ حقوق پرداختی
        public string Date { get; set; }
        // نام متد محاسبه حقوق
        public string OverTimeCalculator { get; set; }
        // حقوق پرداختی
        public int SalaryPaid { get; set; }
 
    }
}
