﻿using System;

namespace OvertimeMethods
{
    public class OvetimePolicies
    {
        public int CalcurlatorA(int BasicSalary, int Allowance, int Transportation)
        {
            return BasicSalary + Allowance + Transportation + (BasicSalary + Allowance) * 2;
        }
        public int CalcurlatorB(int BasicSalary, int Allowance, int Transportation)
        {
            return BasicSalary + Allowance + Transportation + (BasicSalary + Allowance) * 3;
        }
        public int CalcurlatorC(int BasicSalary, int Allowance, int Transportation)
        {
            return BasicSalary + Allowance + Transportation + (BasicSalary + Allowance) * 4;
        }
    }
}
