﻿namespace Common
{
    //just to mark
    public interface IScopedDependency
    {
    }

    public interface ITransientDependency
    {
    }

    public interface ISingletonDependency
    {
    }
}
