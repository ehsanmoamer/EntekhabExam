﻿using System;

namespace OvetimePolicies
{
    public class OvertimeMethods
    {
        public int CalcurlatorA()
        {
            return 1;
        }
        public int CalcurlatorB()
        {
            return 2;
        }
        public int CalcurlatorC()
        {
            return 3;
        }
    }
}
