﻿using System.ComponentModel.DataAnnotations;

namespace Entities.Salary
{
    public class Salary : BaseEntity
    {
        [Required]
        [StringLength(100)]
        public string FirstName { get; set; }
        [Required]
        [StringLength(100)]
        public string LastName { get; set; }

        // حقوق پایه
        [Required]
        public int BasicSalary { get; set; }

        // فوق العاده حق جذب
        [Required]
        public int Allowance { get; set; }

        // حق ایاب و ذهاب
        [Required]
        public int Transportation { get; set; }

        // تاریخ حقوق پرداختی
        [Required]
        [StringLength(8)]
        public string Date { get; set; }

        // نام متد محاسبه حقوق
        [Required]
        public string OverTimeCalculator { get; set; }

        // حقوق پرداختی
        public int SalaryPaid { get; set; }

    }
}
