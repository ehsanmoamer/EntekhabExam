﻿using System;

namespace OvertimePolicies
{
    public class CalculatorA
    {
     
    }
}
